import meggy.Meggy;

class PA5Test1 {

    public static void main(String[] whatever){
        Meggy.setPixel((byte)0,(byte)0, Meggy.Color.BLUE);
    }
}