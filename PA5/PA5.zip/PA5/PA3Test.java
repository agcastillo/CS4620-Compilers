
import meggy.Meggy;

class PA3Test {
    public static void main(String[] whatever){
        {
            Meggy.getPixel((byte)8, (byte)0);

        }
    }
}
