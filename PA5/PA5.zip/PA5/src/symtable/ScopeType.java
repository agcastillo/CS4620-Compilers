package symtable;
public enum ScopeType {
     CLASS, LOCAL;
}